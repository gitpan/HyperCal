#!/usr/bin/perl
#
print "content-type: text/html \n\n";
print "<h1>Foo</h1>\n";
